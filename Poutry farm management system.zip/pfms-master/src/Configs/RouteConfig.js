import React from "react";
import { Redirect } from "react-router-dom";

import { LoginConfig } from "../Pages/Login/LoginConfig";
import { DashboardConfig } from "../Pages/Dashboard/DashboardConfig";
import { UsersConfig } from "../Pages/Users/UsersConfig";
import { GrowHouseConfig } from "../Pages/GrowHouse/GrowHouseConfig";
import { FeedConfig } from "../Pages/Feed/FeedConfig";
import { TreatmentsConfig } from "../Pages/Treatments/TreatmentsConfig";
import { BirdsConfig } from "../Pages/Birds/BirdsConfig";
import { FeedscheduleConfig } from "../Pages/Schedule/Feedschedule/FeedscheduleConfig";
import { VaccinescheduleConfig } from "../Pages/Schedule/Vaccineschedule/VaccinescheduleConfig";
import { ReportsConfig } from "../Pages/Reports/ReportsConfig";
import { Error404PageConfig } from "../Pages/Errors/404/Error404PageConfig";
import { Error500PageConfig } from "../Pages/Errors/500/Error500PageConfig";

const routeConfigs = [
  ...LoginConfig.routes,
  ...DashboardConfig.routes,
  ...UsersConfig.routes,
  ...GrowHouseConfig.routes,
  ...FeedConfig.routes,
  ...TreatmentsConfig.routes,
  ...BirdsConfig.routes,
  ...FeedscheduleConfig.routes,
  ...VaccinescheduleConfig.routes,
  ...ReportsConfig.routes,
  ...Error404PageConfig.routes,
  ...Error500PageConfig.routes,
];

const routes = [
  ...routeConfigs,
  {
    component: () => <Redirect to="/pages/errors/error-404" />,
  },
];

export default routes;
