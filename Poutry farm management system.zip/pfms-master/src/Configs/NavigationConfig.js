const navigationConfig = [
    {
      id: "Main",
      title: "MAIN",
      type: "group",
      children: [
        {
          id: "dashboard",
          title: "Dashboard",
          type: "item",
          icon: "apps",
          url: "/dashboard",
          exact: true,
        },
        {
          id: "users",
          title: "Users",
          type: "item",
          url: "/pages/users",
          exact: true,
          icon: "people"
        },
        {
          id: "Manage",
          title: "Basic Registration",
          type: "collapse",
          icon: "noteadd",
  
          children: [
            {
              id: "growhouse",
              title: "Grow House",
              type: "item",
              url: "/pages/growhouse",
              exact: true,
            },
            {
              id: "feed",
              title: "Feed",
              type: "item",
              url: "/pages/feed",
              exact: true,
            },
            {
              id: "treament",
              title: "Vaccines",
              type: "item",
              url: "/pages/vaccines",
              exact: true,
            }
          ],
        },
        {
          id: "birds",
          title: "Birds",
          type: "item",
          url: "/pages/birds",
          exact: true,
          icon: "pets",
        },
        {
          id: "schedule",
          title: "Schedules",
          type: "collapse",
          icon: "people",
  
          children: [
            {
              id: "feedschedule",
              title: "Feed Schedule",
              type: "item",
              url: "/pages/feedschedule",
              exact: true,
            },
            {
              id: "vaccineschedule",
              title: "Vaccine Schedule",
              type: "item",
              url: "/pages/vaccineschedule",
              exact: true,
            },
          ],
        },
        {
          id: "reports",
          title: "Reports",
          type: "collapse",
          icon: "report",
          children: [
            {
              id: "growhousereport",
              title: "Grow House Reports",
              type: "item",
              url: "/pages/growhousereport",
              exact: true,
            },
            {
              id: "feedreport",
              title: "Feed Reports",
              type: "item",
              url: "/pages/feedreport",
              exact: true,
            },
            {
              id: "vaccinereport",
              title: "Vaccine Reports",
              type: "item",
              url: "/pages/vaccinereport",
              exact: true,
            },
          ],
        }
      ],
    },
    
  ];
  
  export default navigationConfig;
  