import React from "react";
import SysAppBar from "../Components/AppBar/SysAppBar";

const Header = () => <SysAppBar drawerWidth={240} />;

export default Header;