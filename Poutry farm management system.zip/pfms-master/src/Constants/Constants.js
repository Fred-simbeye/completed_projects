///system name
export const SystemName = "PoultryFarm";
//////////////

///Api url
export const BaseUrl = "http://localhost/pfmsRestApi/v1/";
/////////////

///Login Api
export const LoginApi = "authentication-api.php";
/////////////

///View all users api
export const ViewAllUsersApi = "view-users-api.php";
////////////

export const Viewtreatments = "view-treatments-api.php";

export const Createtreatments = "create-treatments-api.php";

export const GetCitiesApi = "view-cities-api.php";

export const GetroleApi = "view-role-api.php";

export const Createuser = "create-user-api.php";

export const Viewgrowhouse = "view-grow-house-api.php";

export const Creategrowhouse = "create-grow-house-api.php";

export const Viewfeed = "view-feed-api.php";

export const Createfeed = "create-feed-api.php";

export const Viewrole = "view-user-role-api.php";

export const Viewbirds = "view-birds-api.php";

export const Createbird = "create-bird-api.php";

export const Viewemptygrowhouse = "view-empty-grow-house-api.php";

export const Viewoccupiedgrowhouse = "view-occupied-grow-house-api.php";

export const Viewduration = "view-duration-api.php";

export const Viewfeedschedule = "view-feed-schedule-api.php";

export const Createfeedschedule = "create-feed-schedule-api.php";

export const Createvaccineschedule = "create-vaccine-schedule-api.php";

export const Viewvaccineschedule = "view-vaccine-schedule-api.php";
