import React from "react";

const LayoutContext = React.createContext({});

export default LayoutContext;