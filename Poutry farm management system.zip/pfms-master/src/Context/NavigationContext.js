import React from "react";

const NavigationContext = React.createContext({});

export default NavigationContext;