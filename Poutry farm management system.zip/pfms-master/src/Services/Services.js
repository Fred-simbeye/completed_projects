import { BaseUrl } from '../Constants/Constants'

export function Get(api) {

  return new Promise((resolve, reject) => {
    fetch(BaseUrl + api, { method: "GET" })
      .then((response) => response.json())
      .then((responnseJson) => {
        resolve(responnseJson);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function Post(api, data) {

  return new Promise((resolve, reject) => {
    fetch(BaseUrl + api, {
      method: 'POST',
      body: JSON.stringify(data)
    })
      .then((response) => response.json())
      .then((responnseJson) => {
        resolve(responnseJson);
      })
      .catch((error) => {
        reject(error);
      });
  });
}