import React, { useEffect, useState } from "react";
import {
  Grid,
  makeStyles,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Button,
} from "@material-ui/core";

import { useForm, Controller } from "react-hook-form";

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
  paper: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 5,
  },
  chip: {
    background: "#357a38",
    color: "white",
    padding: "0 30px",
    boxShadow: "0 3px 5px 2px #81c784",
  },
  chip2: {
    background: "#b71c1c",
    color: "white",
    padding: "0 30px",
    boxShadow: "0 3px 5px 2px #e53935",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 280,
  },
  formControl2: {
    margin: theme.spacing(1),
    minWidth: 580,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const AddGrowHouse = (props) => {
  const classes = useStyles();

  const [citylist, setCitylist] = useState([]);
  const [rolelist, setRolelist] = useState([]);

  const { register, handleSubmit, errors, control } = useForm({
    mode: "all",
  });

  const { addoredit } = props;

  const onSubmit = (data) => addoredit(data);
  
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
            name="growhouse"
            label="Grow House Name or Number"
            fullWidth
            type="text"
            error={!!errors.growhouse}
            helperText={errors.growhouse ? "This field is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="capacity"
            label="Capacity"
            fullWidth
            type="text"
            error={!!errors.capacity}
            helperText={errors.capacity ? "Capacity is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={
              !!errors.growhouse ||
              !!errors.capacity
            }
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddGrowHouse;
