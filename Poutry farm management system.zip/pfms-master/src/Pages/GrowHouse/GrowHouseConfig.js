import GrowHouse from "./GrowHouse";

export const GrowHouseConfig = {
  routes: [
    {
      path: "/pages/growhouse",
      exact: true,
      component: GrowHouse
    }
  ]
};