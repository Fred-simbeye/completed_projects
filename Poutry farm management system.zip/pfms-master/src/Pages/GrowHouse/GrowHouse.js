import React, { useState, useEffect, forwardRef } from "react";
import AppLayout from "../../Components/AppLayout/AppLayout";
import AppBreadcrumbs from "../../Components/BreadCrumbs/AppBreadCrumbs";
import { Typography, Grid, Button, makeStyles } from "@material-ui/core";
import MaterialTable from "material-table";

import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";

import jwt_decode from "jwt-decode";

import {
  Viewgrowhouse,
  Creategrowhouse,
  Viewrole,
} from "../../Constants/Constants";
import Popup from "../../Components/Reusables/Popup";
import AddGrowHouse from "./AddGrowHouse/AddGrowHouse";
import { Get, Post } from "../../Services/Services";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
}));

toast.configure();

const GrowHouse = (props) => {
  const { history } = props;
  const classes = useStyles();
  const [list, setList] = useState([]);
  const [rolelist, setRoleList] = useState([]);

  if (localStorage.getItem("token")) {
    var decoded = jwt_decode(localStorage.getItem("token"));
    var roleID = decoded.data.roleID;
  } else {
    history.push({
      pathname: "/",
    });
  }

  const [roleid] = useState({ roleID: roleID });
  useEffect(() => {
    Get(Viewgrowhouse).then((result) => {
      setList(result);
    });
  }, [list.length]);

  useEffect(() => {
    Post(Viewrole, roleid).then((result) => {
      setRoleList(result);
    });
  }, [rolelist.length]);

  const columns = [
    { title: "Grow House", field: "growhouse" },
    { title: "Capacity", field: "capacity" },
    { title: "State", field: "state" },
  ];

  var data = list.map((item) => {
    let alldata = {
      id: item.id,
      growhouse: item.growhouse,
      capacity: item.capacity,
      state: item.state,
    };
    return alldata;
  });
  const options = {
    exportButton: true,
  };

  const [openpopup, setOpenpopup] = useState(false);

  const handleOpen = () => {
    setOpenpopup(true);
  };

  const addoredit = (data) => {
    Post(Creategrowhouse, data).then((result) => {
      let response = result;
      if (response.http_code === 300) {
        Get(Viewgrowhouse).then((result) => {
          setList(result);
        });
        toast.success("registration successful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 302) {
        toast.error("exists", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 301) {
        toast.error("registration unsuccessful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 303) {
        toast.error("All data needed !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 304) {
        toast.error(" Access Denied !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
    });
  };
  return (
    <AppLayout>
      {rolelist.map((item) => {
        return (
          <Grid container className={classes.my3} alignItems="center">
            <Grid item className={classes.mRight}>
              <Typography variant="h5" component="h1">
                Grow House
              </Typography>
            </Grid>
            {item.write === "1" && (
              <Grid item>
                <Button
                  onClick={handleOpen}
                  variant="outlined"
                  color="primary"
                  size="small"
                >
                  Add Grow House
                </Button>
              </Grid>
            )}
          </Grid>
        );
      })}
      <AppBreadcrumbs path={history} />
      <MaterialTable
        title="Grow House"
        icons={tableIcons}
        columns={columns}
        data={data}
        options={options}
      />
      <Popup
        title="Grow House Form"
        openpopup={openpopup}
        setOpenpopup={setOpenpopup}
      >
        <AddGrowHouse addoredit={addoredit} />
      </Popup>
    </AppLayout>
  );
};

export default GrowHouse;
