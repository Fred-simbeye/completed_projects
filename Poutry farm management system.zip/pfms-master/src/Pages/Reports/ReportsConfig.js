import Reports from "./Reports";

export const ReportsConfig = {
  routes: [
    {
      path: "/pages/reports",
      exact: true,
      component: Reports
    }
  ]
};