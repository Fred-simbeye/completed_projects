import React, { useState, forwardRef } from "react";
import AppLayout from "../../Components/AppLayout/AppLayout";
import AppBreadcrumbs from "../../Components/BreadCrumbs/AppBreadCrumbs";
import {
  Typography,
  Grid,
  Button,
  makeStyles,
  Select,
  FormControl,
  InputLabel,
  MenuItem,
  FormHelperText,
  Paper,
  TextField,
} from "@material-ui/core";
import MaterialTable from "material-table";

import { Get, Post } from "../../Services/Services";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";
import { useForm } from "react-hook-form";

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 380,
  },
}));

toast.configure();

const Reports = (props) => {
  const { history } = props;
  const classes = useStyles();

//   if (localStorage.getItem("token")) {
//   } else {
//     history.push({
//       pathname: "/",
//     });
//   }

  const [api, setApi] = React.useState("");

  const handleChange = (event) => {
    setApi(event.target.value);
  };

  const columnsbirth = [
    { title: "Name/Tag", field: "name" },
    { title: "Farm", field: "farm" },
    { title: "Race", field: "race" },
    { title: "Type", field: "type" },
    { title: "Date of Birth", field: "dob" },
  ];
  const columnsdeath = [
    { title: "Name/Tag", field: "name" },
    { title: "Farm", field: "farm" },
    { title: "Race", field: "race" },
    { title: "Type", field: "type" },
    { title: "Date of Death", field: "dod" },
  ];
  const columnssold = [
    { title: "Name/Tag", field: "name" },
    { title: "Farm", field: "farm" },
    { title: "Race", field: "race" },
    { title: "Type", field: "type" },
    { title: "Date of Sold", field: "dl" },
  ];
  const columnspregnant = [
    { title: "Name/Tag", field: "name" },
    { title: "Farm", field: "farm" },
    { title: "Race", field: "race" },
    { title: "Type", field: "type" },
  ];
  const columnsevent = [
    { title: "Name/Tag", field: "tag" },
    { title: "Event Type", field: "eventtype" },
    { title: "Vaccine", field: "vaccine" },
    { title: "Date", field: "date" },
    { title: "Comments", field: "comments" },
  ];

  const options = {
    exportButton: true,
  };

  const onSubmit = (newdata) => {
    // if (api === "view-birth-report-api.php") {
    //   Post(api, newdata).then((result) => {
    //     setBirthList(result);
    //   });
    // }
    // if (api === "view-death-report-api.php") {
    //   Post(api, newdata).then((result) => {
    //     setDeathList(result);
    //   });
    // }
    // if (api === "view-sold-report-api.php") {
    //   Post(api, newdata).then((result) => {
    //     setSoldList(result);
    //   });
    // }
    // if (api === "view-event-report-api.php") {
    //   Post(api, newdata).then((result) => {
    //     setEventList(result);
    //   });
    // }
  };

  const handlepregreport = () => {
    // Get(Viewpregnantreport).then((result) => {
    //   setPregnantList(result);
    // });
  };

  const { register, handleSubmit, errors } = useForm({
    mode: "all",
  });

  return (
    <AppLayout>
      <Grid container className={classes.my3} alignItems="center">
        <Grid item className={classes.mRight}>
          <Typography variant="h5" component="h1">
            Reports
          </Typography>
        </Grid>
      </Grid>
      <AppBreadcrumbs path={history} />
      <Grid container spacing={3} direction="column">
        <Grid item xs={12}>
          <Paper elevation={3} style={{ padding: 10 }}>
            <Grid item xs={12} sm={4}>
              <FormControl className={classes.formControl}>
                <InputLabel id="api-label">Report Type</InputLabel>
                <Select
                  labelId="api-label"
                  id="api"
                  value={api}
                  onChange={handleChange}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {/* <MenuItem value={Viewbirthreport}>Birth Report</MenuItem>
                  <MenuItem value={Viewdeathreport}>Death Report</MenuItem>
                  <MenuItem value={Viewsoldreport}>Sold Report</MenuItem>
                  <MenuItem value={Vieweventreport}>Events Report</MenuItem>
                  <MenuItem value={Viewpregnantreport}>
                    Pregnant Report
                  </MenuItem> */}
                </Select>
                <FormHelperText>Select the report type</FormHelperText>
              </FormControl>
            </Grid>
            <form onSubmit={handleSubmit(onSubmit)}>
              <Grid container spacing={2}>
                {api !== "view-pregnant-report-api.php" && (
                  <Grid item xs={12} sm={4}>
                    <TextField
                      name="df"
                      label="Start Date"
                      fullWidth
                      type="date"
                      error={!!errors.df}
                      helperText={errors.df ? "Start Date is required" : ""}
                      inputRef={register({ required: true })}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Grid>
                )}
                {api !== "view-pregnant-report-api.php" && (
                  <Grid item xs={12} sm={4}>
                    <TextField
                      name="dt"
                      label="End Date"
                      fullWidth
                      type="date"
                      error={!!errors.dt}
                      helperText={errors.dt ? "End Date is required" : ""}
                      inputRef={register({ required: true })}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Grid>
                )}
                {api !== "view-pregnant-report-api.php" && (
                  <Grid item xs={12}>
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      disabled={!!errors.df || !!errors.dt}
                    >
                      Submit
                    </Button>
                  </Grid>
                )}
              </Grid>
            </form>
            {api === "view-pregnant-report-api.php" && (
              <Grid item xs={12}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  onClick={handlepregreport}
                >
                  Submit
                </Button>
              </Grid>
            )}
          </Paper>
        </Grid>
        <Grid item xs={12}>
          {api === "view-birth-report-api.php" && (
            <MaterialTable
              title="Birth Report"
              icons={tableIcons}
              columns={columnsbirth}
              options={options}
              //data={birthdata}
            />
          )}
          {api === "view-death-report-api.php" && (
            <MaterialTable
              title="Death Report"
              icons={tableIcons}
              columns={columnsdeath}
              options={options}
              //data={deathdata}
            />
          )}
          {api === "view-sold-report-api.php" && (
            <MaterialTable
              title="Sold Report"
              icons={tableIcons}
              columns={columnssold}
              options={options}
              //data={solddata}
            />
          )}
          {api === "view-event-report-api.php" && (
            <MaterialTable
              title="Events Report"
              icons={tableIcons}
              columns={columnsevent}
              options={options}
              //data={eventdata}
            />
          )}
          {api === "view-pregnant-report-api.php" && (
            <MaterialTable
              title="Pregnant Report"
              icons={tableIcons}
              columns={columnspregnant}
              options={options}
              //data={pregdata}
            />
          )}
        </Grid>
      </Grid>
    </AppLayout>
  );
};

export default Reports;
