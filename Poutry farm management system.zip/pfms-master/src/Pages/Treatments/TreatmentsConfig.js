import Treatments from "./Treatments";

export const TreatmentsConfig = {
  routes: [
    {
      path: "/pages/vaccines",
      exact: true,
      component: Treatments
    }
  ]
};