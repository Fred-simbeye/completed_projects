import React from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import { Button } from "@material-ui/core";
import { useForm } from "react-hook-form";

const AddTreatments = (props) => {
  const { register, handleSubmit, errors } = useForm({
    mode: "all",
  });

  const { addoredit } = props;

  const onSubmit = (data) => addoredit(data);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12}>
          <TextField
            name="treatment"
            label="Treatment"
            fullWidth
            type="text"
            error={!!errors.treatment}
            helperText={errors.treatment ? "Treatment is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={12}>
          <TextField
            name="type"
            label="Type"
            fullWidth
            type="text"
            error={!!errors.type}
            helperText={errors.type ? "Type is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={!!errors.treatment}
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddTreatments;
