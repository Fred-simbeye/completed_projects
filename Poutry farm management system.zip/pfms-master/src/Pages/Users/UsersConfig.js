import Users from "./Users";

export const UsersConfig = {
  routes: [
    {
      path: "/pages/users",
      exact: true,
      component: Users
    }
  ]
};