import React, { useEffect, useState } from "react";
import {
  Grid,
  makeStyles,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Button,
} from "@material-ui/core";

import { useForm, Controller } from "react-hook-form";
import { Get } from "../../../Services/Services";
import { GetCitiesApi, GetroleApi } from "../../../Constants/Constants";

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
  paper: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 5,
  },
  chip: {
    background: "#357a38",
    color: "white",
    padding: "0 30px",
    boxShadow: "0 3px 5px 2px #81c784",
  },
  chip2: {
    background: "#b71c1c",
    color: "white",
    padding: "0 30px",
    boxShadow: "0 3px 5px 2px #e53935",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 280,
  },
  formControl2: {
    margin: theme.spacing(1),
    minWidth: 580,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const AddUser = (props) => {
  const classes = useStyles();

  const [citylist, setCitylist] = useState([]);
  const [rolelist, setRolelist] = useState([]);

  const { register, handleSubmit, errors, control } = useForm({
    mode: "all",
  });

    useEffect(() => {
      Get(GetCitiesApi).then((result) => {
        setCitylist(result);
      });
    }, [citylist.length]);

    useEffect(() => {
      Get(GetroleApi).then((result) => {
        setRolelist(result);
      });
    }, []);

  const { addoredit } = props;

  const onSubmit = (data) => addoredit(data);
  
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={4}>
          <TextField
            name="username"
            label="Username"
            fullWidth
            type="text"
            error={!!errors.username}
            helperText={errors.username ? "Username is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <FormControl
            className={classes.formControl}
            error={Boolean(errors.role)}
          >
            <InputLabel shrink id="role-label">
              Role
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {rolelist.map((items) => {
                    return (
                      <MenuItem key={items.roleID} value={items.roleID}>
                        {items.role_title}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="role"
              rules={{ required: "Role is required" }}
              control={control}
              defaultValue=""
            />
            <FormHelperText>
              {errors.role && errors.role.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="firstname"
            label="First name"
            fullWidth
            type="text"
            error={!!errors.firstname}
            helperText={errors.firstname ? "First name is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="othername"
            label="Other name"
            fullWidth
            type="text"
            inputRef={register}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="lastname"
            label="Last name"
            fullWidth
            type="text"
            error={!!errors.lastname}
            helperText={errors.lastname ? "Last name is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="identification_number"
            label="NRC"
            fullWidth
            type="text"
            error={!!errors.identification_number}
            helperText={
              errors.identification_number
                ? errors.identification_number.message
                : ""
            }
            inputRef={register({
              required: "NRC is required",
              pattern: {
                value: /^\d\d\d\d\d\d\/\d\d\/\d$/,
                message: "Invalid NRC",
              },
            })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="email"
            label="Email"
            fullWidth
            type="email"
            error={!!errors.email}
            helperText={errors.email ? errors.email.message : ""}
            inputRef={register({
              required: "Email is required",
              pattern: {
                value: /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/,
                message: "Invalid email",
              },
            })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="contact"
            label="Contact Number"
            fullWidth
            type="text"
            error={!!errors.contact}
            helperText={errors.contact ? errors.contact.message : ""}
            inputRef={register({
              required: "Contact number is required",
              pattern: {
                value: /^\d\d\d\d\d\d\d\d\d\d$/,
                message: "Invalid contact number",
              },
            })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="residentialAddress"
            label="Residential Address"
            fullWidth
            type="text"
            error={!!errors.residentialAddress}
            helperText={
              errors.residentialAddress ? "Residential Address is required" : ""
            }
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <FormControl
            className={classes.formControl}
            error={Boolean(errors.city)}
          >
            <InputLabel shrink id="city-label">
              City
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {citylist.map((items) => {
                    return (
                      <MenuItem key={items.cityId} value={items.cityId}>
                        {items.city}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="city"
              defaultValue=""
              rules={{ required: "City is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.city && errors.city.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={4}>
          <TextField
            name="password"
            label="Password"
            fullWidth
            type="text"
            error={!!errors.password}
            helperText={errors.password ? errors.password.message : ""}
            inputRef={register({
              required: "Password is required",
              minLength: 6,
            })}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <FormControl
            className={classes.formControl}
            error={Boolean(errors.status)}
          >
            <InputLabel shrink id="status-label">
              Status
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  <MenuItem value={1}>Activate</MenuItem>
                  <MenuItem value={0}>Deactivate</MenuItem>
                </Select>
              }
              name="status"
              defaultValue=""
              rules={{ required: "Status is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.status && errors.status.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={
              !!errors.username ||
              !!errors.role ||
              !!errors.firstname ||
              !!errors.lastname ||
              !!errors.identification_number ||
              !!errors.email ||
              !!errors.contact ||
              !!errors.residentialAddress ||
              !!errors.city ||
              !!errors.password ||
              !!errors.status
            }
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddUser;
