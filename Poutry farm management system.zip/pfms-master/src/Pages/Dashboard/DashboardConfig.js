import Dashboard from "./Dashboard";

export const DashboardConfig = {
  routes: [
    {
      path: "/dashboard",
      exact: true,
      component: Dashboard
    }
  ]
};