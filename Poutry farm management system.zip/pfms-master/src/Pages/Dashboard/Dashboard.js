import React from "react";
import AppLayout from "../../Components/AppLayout/AppLayout";
import { Grid, makeStyles, Typography } from "@material-ui/core";
import AppBreadcrumbs from "../../Components/BreadCrumbs/AppBreadCrumbs";
import Clock from "react-live-clock";
import jwt_decode from "jwt-decode";
import moment from 'moment'

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
  mLeft: {
    marginLeft: "50rem",

    marginRight: ".85rem",
  },
}));

const Dashboard = (props) => {
  const { history } = props;
  const classes = useStyles();

  if (localStorage.getItem("token")) {
    var decoded = jwt_decode(localStorage.getItem("token"));
    var fullname =
      decoded.data.firstname +
      " " +
      decoded.data.othername +
      " " +
      decoded.data.lastname;
  } else {
    history.push({
      pathname: "/farmsfull",
    });
  }

  var date = moment()
      .utcOffset('+05:30')
      .format('DD-MMM-YYYY');
  return (
    <AppLayout>
      <Grid container className={classes.my3} alignItems="center">
        <Grid item className={classes.mRight}>
          <Typography variant="h6" component="h1">
            Welcome
          </Typography>
        </Grid>
        <Grid item>
          <Typography variant="h6" component="h1">
            {fullname}
          </Typography>
        </Grid>
        <Grid item className={classes.mLeft}>
          <Typography variant="h6" component="h1">
            <Clock
              format="HH:mm:ss"
              timezone={"Africa/maputo"}
              interval={1000}
              ticking={true}
            />
          </Typography>
        </Grid>
        <Grid item>
          <Typography variant="h6" component="h1">
            {date}
          </Typography>
        </Grid>
      </Grid>

      <AppBreadcrumbs path={history} />
    
    </AppLayout>
  );
};

export default Dashboard;
