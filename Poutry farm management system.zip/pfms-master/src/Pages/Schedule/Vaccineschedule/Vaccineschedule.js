import React, { useState, useEffect, forwardRef } from "react";
import AppLayout from "../../../Components/AppLayout/AppLayout";
import AppBreadcrumbs from "../../../Components/BreadCrumbs/AppBreadCrumbs";

import Popup from "../../../Components/Reusables/Popup";
import { Get, Post } from "../../../Services/Services";

import jwt_decode from "jwt-decode";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { Button, Grid, makeStyles, Paper, Typography } from "@material-ui/core";
import { Createvaccineschedule, Viewvaccineschedule, Viewrole } from "../../../Constants/Constants";
import {
  Appointments,
  AppointmentTooltip,
  DateNavigator,
  DayView,
  MonthView,
  Scheduler,
  TodayButton,
  Toolbar,
  ViewSwitcher,
  WeekView,
} from "@devexpress/dx-react-scheduler-material-ui";
import { ViewState } from "@devexpress/dx-react-scheduler";
import moment from "moment";

import AddVaccineSchedule from "./AddVaccineSchedule/AddVaccineSchedule";

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
}));


toast.configure();

const Vaccineschedule = (props) => {
  const { history } = props;
  const classes = useStyles();
  const [list, setList] = useState([]);
  const [rolelist, setRoleList] = useState([]);

  if (localStorage.getItem("token")) {
    var decoded = jwt_decode(localStorage.getItem("token"));
    var roleID = decoded.data.roleID;
  } else {
    history.push({
      pathname: "/",
    });
  }
  const [roleid] = useState({ roleID: roleID });

  useEffect(() => {
    Get(Viewvaccineschedule).then((result) => {
      setList(result);
    });
  }, [list.length]);

  useEffect(() => {
    Post(Viewrole, roleid).then((result) => {
      setRoleList(result);
    });
  }, [rolelist.length]);

  var data = list.map((item) => {
    let alldata = {
      startDate: item.startdate + 'T' + item.time,
      title: 'Vaccinate birds in ' + item.growhouse + ' Vaccine: ' + item.vaccine,
      rRule: item.duration,
      id: item.id,
    };
    return alldata;
  });

  var date = moment().utcOffset("+05:30").format("YYYY-MM-DD");

  // const schedulerData = [
  //   {
  //     startDate: "2020-11-30T09:45",
  //     title: "Meeting",
  //     rRule: "FREQ=DAILY;COUNT=30",
  //     exDate: "20181205T091100Z",
  //   },
    
  // ];

  const [openpopup, setOpenpopup] = useState(false);

  const handleOpen = () => {
    setOpenpopup(true);
  };

  const addoredit = (data) => {
    Post(Createvaccineschedule, data).then((result) => {
      let response = result;
      if (response.http_code === 300) {
        Get(Viewvaccineschedule).then((result) => {
          setList(result);
        });
        toast.success("registration successful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 302) {
        toast.error("exists", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 301) {
        toast.error("registration unsuccessful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 303) {
        toast.error("All data needed !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 304) {
        toast.error(" Access Denied !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
    });
  };
  return (
    <AppLayout>
      {rolelist.map((item) => {
        return (
          <Grid container className={classes.my3} alignItems="center">
            <Grid item className={classes.mRight}>
              <Typography variant="h5" component="h1">
                Vaccine Schedule
              </Typography>
            </Grid>
            {item.write === "1" && (
              <Grid item>
                <Button
                  onClick={handleOpen}
                  variant="outlined"
                  color="primary"
                  size="small"
                >
                  Add Vaccine Schedule
                </Button>
              </Grid>
            )}
          </Grid>
        );
      })}
      <AppBreadcrumbs path={history} />
      <Paper>
        <Scheduler data={data} height={600}>
          <ViewState
            defaultCurrentDate={date}
            defaultCurrentViewName="Week"
          />
          <DayView startDayHour={5} endDayHour={24} />
          <WeekView startDayHour={5} endDayHour={24} />
          <MonthView />
          <Toolbar />
          <ViewSwitcher />
          <DateNavigator />
          <TodayButton />
          <Appointments />
          <AppointmentTooltip showCloseButton />
        </Scheduler>
      </Paper>
      <Popup
        title="Vaccine schedule Form"
        openpopup={openpopup}
        setOpenpopup={setOpenpopup}
      >
        <AddVaccineSchedule addoredit={addoredit}/>
      </Popup>
    </AppLayout>
  );
};

export default Vaccineschedule;
