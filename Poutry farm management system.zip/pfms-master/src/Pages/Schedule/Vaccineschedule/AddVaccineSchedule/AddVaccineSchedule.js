import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import {
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  makeStyles,
  MenuItem,
  Select,
} from "@material-ui/core";
import { Controller, useForm } from "react-hook-form";
import {
  Viewduration,
  Viewfeed,
  Viewoccupiedgrowhouse,
  Viewtreatments,
} from "../../../../Constants/Constants";
import { Get } from "../../../../Services/Services";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  formControl2: {
    margin: theme.spacing(1),
    minWidth: 400,
  },
}));

const AddVaccineSchedule = (props) => {
  const classes = useStyles();
  const { register, handleSubmit, errors, control } = useForm({
    mode: "all",
  });

  const { addoredit } = props;

  const [vlist, setVList] = useState([]);
  const [glist, setGList] = useState([]);
  const [dlist, setDList] = useState([]);
  const onSubmit = (data) => addoredit(data);

  useEffect(() => {
    Get(Viewtreatments).then((result) => {
      setVList(result);
    });
  }, [vlist.length]);

  useEffect(() => {
    Get(Viewoccupiedgrowhouse).then((result) => {
      setGList(result);
    });
  }, [glist.length]);

  useEffect(() => {
    Get(Viewduration).then((result) => {
      setDList(result);
    });
  }, [dlist.length]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <FormControl
            className={classes.formControl2}
            error={Boolean(errors.vaccine)}
          >
            <InputLabel shrink id="vaccine-label">
              Vaccines
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {vlist.map((items) => {
                    return (
                      <MenuItem key={items.id} value={items.id}>
                        {items.vaccine}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="vaccine"
              defaultValue=""
              rules={{ required: "This is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.vaccine && errors.vaccine.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl
            className={classes.formControl2}
            error={Boolean(errors.growhouse)}
          >
            <InputLabel shrink id="growhouse-label">
              Grow house
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {glist.map((items) => {
                    return (
                      <MenuItem key={items.id} value={items.id}>
                        {items.growhouse}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="growhouse"
              defaultValue=""
              rules={{ required: "This is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.growhouse && errors.growhouse.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="startdate"
            label="Date"
            fullWidth
            type="date"
            error={!!errors.startdate}
            helperText={errors.startdate ? "This is required" : ""}
            inputRef={register({ required: true })}
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="starttime"
            label="Time"
            fullWidth
            type="time"
            error={!!errors.starttime}
            helperText={errors.starttime ? "This is required" : ""}
            inputRef={register({ required: true })}
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl
            className={classes.formControl2}
            error={Boolean(errors.duration)}
          >
            <InputLabel shrink id="duration-label">
              Duration
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {dlist.map((items) => {
                    return (
                      <MenuItem key={items.frequency} value={items.frequency}>
                        {items.days}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="duration"
              defaultValue=""
              rules={{ required: "This is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.duration && errors.duration.message}
            </FormHelperText>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={
              !!errors.duration ||
              !!errors.startdate ||
              !!errors.starttime ||
              !!errors.growhouse ||
              !!errors.vaccine
            }
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddVaccineSchedule;
