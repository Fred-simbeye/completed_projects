import Vaccineschedule from "./Vaccineschedule";

export const VaccinescheduleConfig = {
  routes: [
    {
      path: "/pages/vaccineschedule",
      exact: true,
      component: Vaccineschedule
    }
  ]
};