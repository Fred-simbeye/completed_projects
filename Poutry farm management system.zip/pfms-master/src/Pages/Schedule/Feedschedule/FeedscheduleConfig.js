import Feedschedule from "./Feedschedule";

export const FeedscheduleConfig = {
  routes: [
    {
      path: "/pages/feedschedule",
      exact: true,
      component: Feedschedule
    }
  ]
};