import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import {
  Button,
  FormControl,
  FormHelperText,
  InputLabel,
  makeStyles,
  MenuItem,
  Select,
} from "@material-ui/core";
import { Controller, useForm } from "react-hook-form";
import { Viewemptygrowhouse } from "../../../Constants/Constants";
import { Get } from "../../../Services/Services";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  formControl2: {
    margin: theme.spacing(1),
    minWidth: 400,
  },
}));

const AddBird = (props) => {
  const classes = useStyles();
  const { register, handleSubmit, errors, control } = useForm({
    mode: "all",
  });

  const { addoredit } = props;

  const [list, setList] = useState([]);
  const onSubmit = (data) => addoredit(data);

  useEffect(() => {
    Get(Viewemptygrowhouse).then((result) => {
      setList(result);
    });
  }, [list.length]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
            name="batch"
            label="Batch ID/Number"
            fullWidth
            type="text"
            error={!!errors.batch}
            helperText={errors.batch ? "This is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="number"
            label="Number of Birds"
            fullWidth
            type="number"
            error={!!errors.number}
            helperText={errors.number ? "This is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="date"
            label="Date Brought"
            fullWidth
            type="date"
            error={!!errors.date}
            helperText={errors.date ? "This is required" : ""}
            inputRef={register({ required: true })}
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <FormControl
            className={classes.formControl2}
            error={Boolean(errors.growhouse)}
          >
            <InputLabel shrink id="growhouse-label">
              Grow House
            </InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {list.map((items) => {
                    return (
                      <MenuItem key={items.id} value={items.id}>
                        {items.growhouse}
                      </MenuItem>
                    );
                  })}
                </Select>
              }
              name="growhouse"
              defaultValue=""
              rules={{ required: "This is required" }}
              control={control}
            />
            <FormHelperText>
              {errors.growhouse && errors.growhouse.message}
            </FormHelperText>
          </FormControl>
        </Grid>

        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={
              !!errors.butch ||
              !!errors.number ||
              !!errors.date ||
              !!errors.growhouse
            }
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddBird;
