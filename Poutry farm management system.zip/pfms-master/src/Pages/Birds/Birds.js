import React, { useState, useEffect, forwardRef } from "react";
import AppLayout from "../../Components/AppLayout/AppLayout";
import AppBreadcrumbs from "../../Components/BreadCrumbs/AppBreadCrumbs";
import { Typography, Grid, Button, makeStyles } from "@material-ui/core";
import MaterialTable from "material-table";

import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";

import { Viewbirds, Createbird, Viewrole } from "../../Constants/Constants";
import Popup from "../../Components/Reusables/Popup";
import { Get, Post } from "../../Services/Services";

import jwt_decode from "jwt-decode";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AddBird from "./AddBird/AddBird";

const tableIcons = {
  Add: forwardRef((props, ref) => <AddBox {...props} ref={ref} />),
  Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
  Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
  DetailPanel: forwardRef((props, ref) => (
    <ChevronRight {...props} ref={ref} />
  )),
  Edit: forwardRef((props, ref) => <Edit {...props} ref={ref} />),
  Export: forwardRef((props, ref) => <SaveAlt {...props} ref={ref} />),
  Filter: forwardRef((props, ref) => <FilterList {...props} ref={ref} />),
  FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
  LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
  NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
  PreviousPage: forwardRef((props, ref) => (
    <ChevronLeft {...props} ref={ref} />
  )),
  ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
  Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
  SortArrow: forwardRef((props, ref) => <ArrowDownward {...props} ref={ref} />),
  ThirdStateCheck: forwardRef((props, ref) => <Remove {...props} ref={ref} />),
  ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
};

const useStyles = makeStyles((theme) => ({
  my3: {
    margin: "1.3rem 0",
  },
  mb0: {
    marginBottom: 0,
  },
  mRight: {
    marginRight: ".85rem",
  },
  p1: {
    padding: ".85rem",
  },
}));

toast.configure();

const Birds = (props) => {
  const { history } = props;
  const classes = useStyles();
  const [list, setList] = useState([]);
  const [rolelist, setRoleList] = useState([]);

  if (localStorage.getItem("token")) {
    var decoded = jwt_decode(localStorage.getItem("token"));
    var roleID = decoded.data.roleID;
  } else {
    history.push({
      pathname: "/",
    });
  }
  const [roleid] = useState({ roleID: roleID });

  useEffect(() => {
    Get(Viewbirds).then((result) => {
      setList(result);
    });
  }, [list.length]);

  useEffect(() => {
    Post(Viewrole, roleid).then((result) => {
      setRoleList(result);
    });
  }, [rolelist.length]);

  const columns = [
    { title: "Butch ID/Number", field: "batch" },
    { title: "Grow House", field: "growhouse" },
    { title: "Number Brought In", field: "number" },
    { title: "Date Brought In", field: "date" },
    { title: "Age", field: "age" },
  ];

  var data = list.map((item) => {
    let alldata = {
      batch: item.batch,
      growhouse: item.growhouse,
      number: item.number,
      date: item.date,
      age: item.age + " Days",
    };
    return alldata;
  });
  const options = {
    exportButton: true,
  };

  const [openpopup, setOpenpopup] = useState(false);

  const handleOpen = () => {
    setOpenpopup(true);
  };

  const addoredit = (data) => {
    Post(Createbird, data).then((result) => {
      let response = result;
      if (response.http_code === 300) {
        Get(Viewbirds).then((result) => {
          setList(result);
        });
        toast.success("registration successful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 302) {
        toast.error("exists", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 301) {
        toast.error("registration unsuccessful !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 303) {
        toast.error("All data needed !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 304) {
        toast.error(" Access Denied !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
    });
  };
  
  return (
    <AppLayout>
      {rolelist.map((item) => {
        return (
          <Grid container className={classes.my3} alignItems="center">
            <Grid item className={classes.mRight}>
              <Typography variant="h5" component="h1">
                Birds
              </Typography>
            </Grid>
            {item.write === "1" && (
              <Grid item>
                <Button
                  onClick={handleOpen}
                  variant="outlined"
                  color="primary"
                  size="small"
                >
                  Add Birds
                </Button>
              </Grid>
            )}
          </Grid>
        );
      })}
      <AppBreadcrumbs path={history} />
      <MaterialTable
        title="Birds"
        icons={tableIcons}
        columns={columns}
        data={data}
        options={options}
      />
      <Popup
        title="Bird Form"
        openpopup={openpopup}
        setOpenpopup={setOpenpopup}
      >
        <AddBird addoredit={addoredit} />
      </Popup>
    </AppLayout>
  );
};

export default Birds;
