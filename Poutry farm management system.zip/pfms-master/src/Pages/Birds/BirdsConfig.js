import Birds from "./Birds";

export const BirdsConfig = {
  routes: [
    {
      path: "/pages/birds",
      exact: true,
      component: Birds
    }
  ]
};