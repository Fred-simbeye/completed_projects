import Login from "./Login";

export const LoginConfig = {
  routes: [
    {
      path: "/",
      exact: true,
      component: Login
    }
  ]
};