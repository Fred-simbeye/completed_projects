import React from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Background from "../../Constants/Images/background.jpg";
import { useForm } from "react-hook-form";
import { Post } from "../../Services/Services";
import { LoginApi } from "../../Constants/Constants";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100vh",
  },
  image: {
    backgroundImage: `url(${Background})`,
    backgroundRepeat: "no-repeat",
    backgroundColor:
      theme.palette.type === "light"
        ? theme.palette.grey[50]
        : theme.palette.grey[900],
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(2),
    backgroundColor: "#1B9EF4",
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

toast.configure();

export default function Login(props) {
  const classes = useStyles();
  const { history } = props;

  const { register, handleSubmit, errors } = useForm({
    mode: "all",
  });

  if (localStorage.getItem("token")) {
    history.push({
      pathname: "/dashboard",
    });
  }

  const onSubmit = (data) => {

    Post(LoginApi, data).then((result) => {
      let response = result;
      if (response.http_code === 300) {
        localStorage.setItem("token", response.jwt);
        
        history.push({
          pathname: "/dashboard",
        });
      }
      if (response.http_code === 302) {
        toast.error("Incorrect Username", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 301) {
        toast.error("Incorrect Password!", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 303) {
        toast.error("All data needed !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
      if (response.http_code === 304) {
        toast.error(" Access Denied !", {
          position: toast.POSITION.TOP_CENTER,
        });
      }
    });
  };

  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      <Grid item xs={false} sm={4} md={7} className={classes.image} />
      <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Avatar className={classes.avatar}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Sign in
          </Typography>
          <form className={classes.form} onSubmit={handleSubmit(onSubmit)}>
            <TextField
              variant="outlined"
              margin="normal"
              fullWidth
              label="Username"
              name="username"
              type="text"
              error={!!errors.username}
              helperText={errors.username ? "Username is required" : ""}
              inputRef={register({ required: true })}
            />
            <TextField
              variant="outlined"
              margin="normal"
              fullWidth
              name="password"
              label="Password"
              type="password"
              error={!!errors.password}
              helperText={errors.password ? "Password is required" : ""}
              inputRef={register({ required: true })}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
              disabled={!!errors.username || !!errors.password}
            >
              Sign In
            </Button>
          </form>
        </div>
      </Grid>
    </Grid>
  );
}
