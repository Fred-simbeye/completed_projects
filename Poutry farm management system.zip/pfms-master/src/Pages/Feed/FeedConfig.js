import Feed from "./Feed";

export const FeedConfig = {
  routes: [
    {
      path: "/pages/feed",
      exact: true,
      component: Feed
    }
  ]
};