import React from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import { Button } from "@material-ui/core";
import { useForm } from "react-hook-form";

const AddFeed = (props) => {
  const { register, handleSubmit, errors } = useForm({
    mode: "all",
  });

  const { addoredit } = props;

  const onSubmit = (data) => addoredit(data);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12}>
          <TextField
            name="feed"
            label="Feed"
            fullWidth
            type="text"
            error={!!errors.feed}
            helperText={errors.feed ? "Feed is required" : ""}
            inputRef={register({ required: true })}
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={!!errors.feed}
          >
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default AddFeed;
